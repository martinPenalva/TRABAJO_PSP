using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    public class ReservationDTO
    {
        public long Id { get; set; }
        
        [Required]
        [StringLength(100)]
        public string CustomerName { get; set; } = string.Empty;
        
        [Required]
        [StringLength(20)]
        public string PhoneNumber { get; set; } = string.Empty;
        
        [Required]
        public DateTime ReservationDateTime { get; set; }
        
        [Required]
        [Range(1, 20)]
        public int NumberOfGuests { get; set; }
        
        [StringLength(500)]
        public string? SpecialRequests { get; set; }
        
        [Required]
        public int TableNumber { get; set; }
        
        public bool IsConfirmed { get; set; }
        
        public DateTime CreatedAt { get; set; }
        
        public DateTime? LastModifiedAt { get; set; }

        public static ReservationDTO FromReservation(Reservation reservation, Services.EncryptionService encryptionService)
        {
            return new ReservationDTO
            {
                Id = reservation.Id,
                CustomerName = encryptionService.Decrypt(reservation.CustomerName),
                PhoneNumber = encryptionService.Decrypt(reservation.PhoneNumber),
                ReservationDateTime = reservation.ReservationDateTime,
                NumberOfGuests = reservation.NumberOfGuests,
                SpecialRequests = reservation.SpecialRequests != null ? encryptionService.Decrypt(reservation.SpecialRequests) : null,
                TableNumber = reservation.TableNumber,
                IsConfirmed = reservation.IsConfirmed,
                CreatedAt = reservation.CreatedAt,
                LastModifiedAt = reservation.LastModifiedAt
            };
        }

        public Reservation ToReservation(Services.EncryptionService encryptionService)
        {
            return new Reservation
            {
                Id = Id,
                CustomerName = encryptionService.Encrypt(CustomerName),
                PhoneNumber = encryptionService.Encrypt(PhoneNumber),
                ReservationDateTime = ReservationDateTime,
                NumberOfGuests = NumberOfGuests,
                SpecialRequests = SpecialRequests != null ? encryptionService.Encrypt(SpecialRequests) : null,
                TableNumber = TableNumber,
                IsConfirmed = IsConfirmed,
                CreatedAt = CreatedAt,
                LastModifiedAt = LastModifiedAt
            };
        }
    }
} 